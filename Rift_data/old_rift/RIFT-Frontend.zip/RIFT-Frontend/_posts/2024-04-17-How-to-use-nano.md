---
title: How to use Nano (BLOG IN PROGRESS NOT DONE YET)
description: How to use the built in Text Editor on Ubuntu machines
toc: True
layout: post
---

# Background

Nano is a text editor that was based on vim, a more complicated  program. It's lightweight and easy to use, while vim is more complicated (imagine typing in 3 letter codes). Vim is not too hard to use, but for simplicity, we'll use nano. 


